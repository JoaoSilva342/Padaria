import { db } from "./firebase.js";
import { doc, runTransaction, onSnapshot } from "firebase/firestore";

const slots = ["slot_1","slot_2","slot_3","slot_4"];

renderGallery();

function renderGallery(){

  const app = document.getElementById("app");

  let html = "<div class='row g-4'>";

  for(const slot of slots){

    html += `
      <div class="col-12 col-md-6">
        <div class="card shadow">
          
          <div class="image-container">
            <img id="img-${slot}" />
          </div>

          <div class="card-body text-center">
            <h4>${slot}</h4>
            <p id="likes-${slot}">Likes: 0</p>

            <button class="btn btn-success" onclick="darLike('${slot}')">
              Like
            </button>

          </div>
        </div>
      </div>
    `;
  }

  html += "</div>";
  app.innerHTML = html;

  slots.forEach(slot=>{

    const ref = doc(db,"photos",slot);

    onSnapshot(ref,(snap)=>{

      if(!snap.exists()) return;

      const data = snap.data();

      const img = document.getElementById(`img-${slot}`);
      const likes = document.getElementById(`likes-${slot}`);

      if(data.dataUrl){
        img.src = data.dataUrl;
      }

      likes.innerText = "Likes: " + (data.likesCount || 0);
    });

  });

}

window.darLike = async(slot)=>{

  const gmail = prompt("Gmail (@gmail.com):")?.toLowerCase();

  if(!gmail || !gmail.endsWith("@gmail.com")){
    alert("Só é permitido Gmail.");
    return;
  }

  const likeId = btoa(gmail)
  .replaceAll("/","_")
  .replaceAll("+","-")
  .replaceAll("=","");

  try{

    await runTransaction(db, async(tx)=>{

      const likeRef = doc(db,"likesByEmail",likeId);
      const photoRef = doc(db,"photos",slot);

      const likeSnap = await tx.get(likeRef);

      if(likeSnap.exists()){
        throw "Este Gmail já votou.";
      }

      const photoSnap = await tx.get(photoRef);

      const likes = photoSnap.data()?.likesCount || 0;

      tx.set(likeRef,{gmail});
      tx.set(photoRef,{likesCount:likes+1},{merge:true});

    });

    alert("Like registado!");

  }catch(e){
    alert(e);
  }
}

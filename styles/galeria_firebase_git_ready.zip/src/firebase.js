import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "COLOCA_AQUI",
  authDomain: "COLOCA_AQUI",
  projectId: "COLOCA_AQUI",
  storageBucket: "COLOCA_AQUI.appspot.com",
  messagingSenderId: "COLOCA_AQUI",
  appId: "COLOCA_AQUI"
};

export const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
